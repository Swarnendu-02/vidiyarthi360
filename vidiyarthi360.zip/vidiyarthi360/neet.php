<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>

<body>
    <? include_once("includes/header.php"); ?>
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-2 lyqp-tab-wrap inner-page-tab ">
                    <div class="tab main-bl-bk p-4 rounded">
                        <button class="tablinks bg-transparent border-0 active pt-0 px-0  pb-2 position-relative" onclick="openCity(event, 'overview')">Overview</button>
                        <button class="tablinks tablinks bg-transparent border-0 pt-0 px-0  pb-2 position-relative" onclick="openCity(event, 'date')">Date</button>
                        <button class="tablinks tablinks bg-transparent border-0 pt-0 px-0  pb-2 position-relative" onclick="openCity(event, 'syllabus')">Syllabus</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 lyqp-tab-box">
                    <div id="overview" class="tabcontent active" style="display:block ;">
                        <h2 class="heading inner-heading mb-4"><span class="under-dec">Overview</span></h2>
                        The National Testing Agency (NTA) conducts NEET for admission to MBBS, BDS, AYUSH, Veterinary and other medical/paramedical courses in India. The National Eligibility cum Entrance Test (NEET) is the sole entrance test for admission to MBBS and BDS courses in India. Conducted annually, NEET 2020 will be held across tentatively 154 test centres. With approximately 16 lakh test-takers, NEET is the most important medical entrance examination in India. Both AIIMS and JIPMER MBBS examinations have also been merged with NTA NEET.
                    </div>
                    <div id="date" class="tabcontent ">
                        <h2 class="heading inner-heading mb-4"><span class="under-dec">Date</span></h2>
                        Agency (NTA) conducts NEET for admission to MBBS, BDS, AYUSH, Veterinary and other medical/paramedical courses in India. The National Eligibility cum Entrance Test (NEET) is the sole entrance test for admission to MBBS and BDS courses in India. Conducted annually, NEET 2020 will be held across tentatively 154 test centres. With approximately 16 lakh test-takers, NEET is the most important medical entrance examination in India. Both AIIMS and JIPMER MBBS examinations have also been merged with NTA NEET.
                    </div>
                    <div id="syllabus" class="tabcontent">
                        <h2 class="heading inner-heading mb-4"><span class="under-dec">Syllabus</span></h2>
                        NEET for admission to MBBS, BDS, AYUSH, Veterinary and other medical/paramedical courses in India. The National Eligibility cum Entrance Test (NEET) is the sole entrance test for admission to MBBS and BDS courses in India. Conducted annually, NEET 2020 will be held across tentatively 154 test centres. With approximately 16 lakh test-takers, NEET is the most important medical entrance examination in India. Both AIIMS and JIPMER MBBS examinations have also been merged with NTA NEET.
                    </div>
                </div>
                <div class="col-12 col-md-3" >
                    <div class="main-bk p-4 rounded position-relative">
                        
                        <h2 class="heading inner-heading mb-4">NEET <span class="under-dec">Notification</span></h2>
                        <ul class="noti-content">
                            <li>NEET 2020 admit card has been released, download now <span class="new-noti">NEW</span></li>
                            <li>NEET 2020 exam date postponed to September 13, know more here.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }
    </script>
</body>

</html>