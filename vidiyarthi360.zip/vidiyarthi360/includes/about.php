<div class="container-fluid">
    <div class="container position-relative">
        <div class="row align-items-center py-5 mb-5">
            <div class="col-12 col-md-6 pr-5">
                <div class="col-12">
                    <h6>OUR MEDICAL</h6>
                    <h2 class="font-weight-bold mb-4">We’re Setting the Standards in Research & Clinical Care</h2>
                </div>
                <div class="col-12">
                    <p class="mb-4" style="word-break: break-all; ">We provide the most full medical services, so every person could have the opportunity to receive qualitative medical help. Our Clinic has grown to provide a world class facility for the treatment of tooth loss, dental cosmetics and bore advanced restorative dentistry. We are among the most qualified implant providers in the USA with over 35 years of quality training and experience.</p>
                </div>
            </div>
            <div class="col-12 col-md-6 about-img shadow p-0">
                <img src="images/demo.jpg" class="w-100">
            </div>
        </div>
        <div class="row align-items-center p-5" style="margin-bottom: -90px;
    background: #01d6a3;">
            <div class="col-12 col-md-4 ">
                <div class="col-12  ">
                    <p class="text-center display-5 text-white">000</p>
                    <p class="mb-0 text-center text-white">Total Projects</p>
                </div>

            </div>

        </div>
    </div>
</div>