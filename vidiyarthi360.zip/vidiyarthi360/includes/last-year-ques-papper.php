<div class="conatiner-fluid lyqp-wrap py-5 main-bk">
        <div class="container">
            <div class="row">
                <h2 class="heading mb-5">Last Year Question Paper & <span class="under-dec">Sollutions</span></h2>
                <div class="col-12 lyqp-tab-wrap">
                    <div class="d-flex justify-content-between mb-4">
                        <div class="tab">
                            <button class="tablinks bg-transparent border-0 active pt-0 px-0 mr-5 pb-2 position-relative" onclick="openCity(event, 'neet')">NEET</button>
                            <button class="tablinks tablinks bg-transparent border-0 pt-0 px-0 mr-5 pb-2 position-relative" onclick="openCity(event, 'jee main')">JEE MAIN</button>
                            <button class="tablinks tablinks bg-transparent border-0 pt-0 px-0 mr-5 pb-2 position-relative" onclick="openCity(event, 'jee advance')">JEE ADVANCE</button>
                        </div>
                        <select class="rounded lyqpy">
                            <option>2021</option>
                            <option>2020</option>
                        </select>
                    </div>
                    <div class="lyqp-tab-box">
                        <div id="neet" class="tabcontent active" style="display:block ;">
                            <div class="owl-carousel owl-theme neet-owl">
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                $('.neet-owl').owlCarousel({
                                    loop: false,
                                    margin: 30,
                                    nav: true,
                                    dots: false,
                                    autoplay: false,
                                    responsive: {
                                        0: {
                                            items: 1
                                        },
                                        600: {
                                            items: 3
                                        },
                                        1000: {
                                            items: 4
                                        }
                                    }
                                })
                            </script>
                        </div>

                        <div id="jee main" class="tabcontent">
                            <div class="owl-carousel owl-theme jeenain-owl">
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                $('.jeenain-owl').owlCarousel({
                                    loop: false,
                                    margin: 30,
                                    nav: true,
                                    dots: false,
                                    autoplay: false,
                                    responsive: {
                                        0: {
                                            items: 1
                                        },
                                        600: {
                                            items: 3
                                        },
                                        1000: {
                                            items: 4
                                        }
                                    }
                                })
                            </script>
                        </div>

                        <div id="jee advance" class="tabcontent">
                        <div class="owl-carousel owl-theme jeeadvance-owl">
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="lyqp-card bg-white p-4 rounded position-relative">
                                        <div class="q-icon-box d-flex align-items-center justify-content-center mb-4"><img src="images/pdficon.png"></div>
                                        <h4>Questions Title</h4>
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <div class="lyqp-overlay">
                                            <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                            <a href="#"><i class="fas fa-download"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                                $('.jeeadvance-owl').owlCarousel({
                                    loop: false,
                                    margin: 30,
                                    nav: true,
                                    dots: false,
                                    autoplay: false,
                                    responsive: {
                                        0: {
                                            items: 1
                                        },
                                        600: {
                                            items: 3
                                        },
                                        1000: {
                                            items: 4
                                        }
                                    }
                                })
                            </script>
                        </div>

                        <script>
                            function openCity(evt, cityName) {
                                var i, tabcontent, tablinks;
                                tabcontent = document.getElementsByClassName("tabcontent");
                                for (i = 0; i < tabcontent.length; i++) {
                                    tabcontent[i].style.display = "none";
                                }
                                tablinks = document.getElementsByClassName("tablinks");
                                for (i = 0; i < tablinks.length; i++) {
                                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                                }
                                document.getElementById(cityName).style.display = "block";
                                evt.currentTarget.className += " active";
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>