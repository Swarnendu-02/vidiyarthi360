<div class="container-fluid p-0 store-banner" style="height: 60vh;">

    <div id="carouselExampleFade" class="carousel slide carousel-fade h-100 p-0" data-ride="carousel">
        <div class="carousel-inner h-100">
            <div class="carousel-item active h-100">

                <img src="images/medical-stote-banner.jpg" class="d-block w-100 h-100">

            </div>


        </div>
        <a class="carousel-control-prev shadow" href="#carouselExampleFade" role="button" data-slide="prev">
            <i class="fas fa-arrow-left"></i>
        </a>
        <a class="carousel-control-next shadow" href="#carouselExampleFade" role="button" data-slide="next">
            <i class="fas fa-arrow-right"></i>
        </a>
    </div>


</div>