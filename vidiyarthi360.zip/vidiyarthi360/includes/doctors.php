<div class="container-fluid py-xl-5">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center text-md-left mb-5">
                <div class="row align-items-center">
                    <div class="col-9">
                        <h6>MEET OUR EXPERIENCED</h6>
                        <h2 class=" font-weight-bold">Our Dedicated Doctors</h2>
                        <p class="mb-0">We offer extensive medical procedures to outbound and inbound patients what it is and we are very proud of achievement of our staff, We are all work together to help our all patients for recovery</p>
                    </div>
                    <div class="col-3 text-right">
                        <button type="button" class="btn btn-primary btn-sm shadow main-btn">View All</button>
                    </div>
                </div>
            </div>
            <div class="owl-carousel owl-theme px-3 our-team">
                <div class="item">
                    <div class="card border-0 p-3 doctor-list" style="border-radius: 0 !important;">
                        <div class="position-relative doctor-img-box">
                            <img class=" team-img" src="images/demo.jpg" alt="Card image cap">
                            
                            <div class="" style="position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);z-index:1;">
                                <button class="p-3 border-0" style="background: #324e3c;">-</button>
                                <button>+</button>
                            </div>
                        </div>

                        <div class="card-body text-center p-0 pt-3">
                            <h5 class="card-title inner-title">Swarnendu</h5>
                            <h6 class="card-subtitle mb-2">Designer</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.our-team').owlCarousel({
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true,
            loop: true,
            lazyLoad: true,
            animateOut: 'slideOutDown',
            animateIn: 'flipInX',
            items: 1,
            margin: 0,

            smartSpeed: 450,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 4
                }
            }
        })
    </script>
</div>