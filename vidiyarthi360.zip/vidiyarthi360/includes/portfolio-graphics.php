<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>
<div class="col-12 col-md-4 p-3 float-left" data-aos="fade-up">
    <div class="col-12 portfolio-item position-relative">
        <img src="images/demo.jpg">
        <div class="card-img-overlay text-white rounded-0 fade">
            
            <i class="fas fa-search" style="position: absolute; top: 50%; left:50%; transform:translate(-50%, -50%);"></i>
            <div style="position: absolute; bottom: 1rem;">
                <h5>Project Name</h5>
                <h6 class="mb-0">Project Type</h6>
            </div>
        </div>
    </div>
</div>