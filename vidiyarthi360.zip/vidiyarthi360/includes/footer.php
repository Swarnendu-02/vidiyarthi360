<footer class="cobtainer-fluid py-5 position-relative" style="background: #99d4a8;">
<img src="images/banner-1.jpg" class="d-block w-100 h-100 position-absolute" style="object-fit: cover; opacity:.2; top:0;" alt="...">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 col-md-4 mb-4 mb-md-0">
                    <ul class="list-group">
                        <h5 class="mb-4 border-bottom pb-2 pl-2 text-white">Navigation</h5>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Cras justo odio</li>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Dapibus ac facilisis in</li>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Morbi leo risus</li>
                    </ul>
                </div>
                <div class="col-12 col-md-4 mb-4 mb-md-0">
                    <ul class="list-group">
                        <h5 class="mb-4 border-bottom pb-2 pl-2 text-white">Services</h5>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Cras justo odio</li>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Dapibus ac facilisis in</li>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Morbi leo risus</li>
                    </ul>
                </div>
                <div class="col-12 col-md-4 mb-4 mb-md-0">
                    <ul class="list-group">
                        <h5 class="mb-4 border-bottom pb-2 pl-2 text-white">Subscribe</h5>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">Cras justo odio</li>
                        <li class="list-group-item border-0 p-0 mb-3 bg-transparent text-white">
                            <input type="text" class="form-control text-input" id="inputAddress" placeholder="Name">
                            <button type="button" class="btn btn-primary btn-sm mt-3 shadow main-btn">Large button</button>
                        </li>
                    </ul>
                </div>
                <div class="col-12 mt-0 mt-md-5">
                    <p class="text-center mb-0 text-white">Copyright ©2020 All rights reserved | Designed by</p>
                </div>
            </div>
        </div>
        <script>
            AOS.init({
                easing: 'ease-in-out-sine'
            });
        </script>
    </footer>