<div class="container-fluid main-bl-bk">
        <div class="container">
            <div class="row">
                <div class="d-flex align-items-center justify-content-end" style="height:40px;">
                    <p class="mb-0 mr-3 text-white">
                        <span>
                            <i class="fas fa-mobile m-2"></i>
                        </span>
                        (+91) 9874400739
                    </p>
                    <p class="mb-0 text-white">
                        <span>
                            <i class="fas fa-mobile m-2"></i>
                        </span>
                        (+91) 9874400739
                    </p>
                </div>
            </div>
        </div>
    </div>
    <header class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-3">
                    <div class="h-100 bg-white d-flex align-items-center justify-content-center logo-sub-box">
                        <img src="images/logo.png">
                    </div>
                </div>
                <div class="menu-box col-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <nav class="navigation hidden-xs hidden-sm" id="navigationmenu">
                        <ul>
                            <li class="pb-2 active">Home</li>
                            <li class="pb-2">About Us</li>
                            <li class="pb-2">Counciling</li>
                            <li class="pb-2">Blog</li>
                            <li class="pb-2">Contact Us</li>
                            <li class="pb-2">Testimonial</li>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white ml-4" onclick="logindown()">Login</button>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>