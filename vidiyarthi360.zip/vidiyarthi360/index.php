<!DOCTYPE html>
<html lang="en">
<? include_once("includes/pagesource.php"); ?>
<body>
<? include_once("includes/header.php"); ?>
    <div class="banner position-relative">
        <img src="images/ezgif.jpg">
        <div class="banner-inner-content">
            <div class="text-center">
                <h2 class="text-white mb-3">TO GET YOUR FREE COUNCILING <span>HERE</span></h2>
                <h4 class="text-white mb-5">Digital Classes with best teachers &amp; Study materials</h4>
                <button class="rounded main-btn-bk border-0 py-2 px-4 text-white" onclick="window.location.href='counciling.php'">Click Now</button>
            </div>
        </div>
    </div>
    <div class="containe-fluid sec-1 pt-5 pt-md-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="sec-1-wrap main-bk rounded">
                        <div class="dark-box main-bl-bk p-4">
                            <p class="text-white">Dicover Yourself</p>
                            <h3 class="text-white mb-3 mb-md-5" style="line-height: 40px;">A Journy To Your Degree from <b>Vidiyarthi</b></h3>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white">Live Test</button>
                        </div>
                        <div class="p-4 sec-1-rt">
                            <div class="sec-1-icon-box d-flex align-items-center justify-content-center mb-0 mb-md-4 bg-white"><img src="images/sec-1-1 (2).png"></div>
                            <h5 class="mb-0 mb-md-4 ml-4 ml-md-0">NEET</h5>
                            <p class="mb-0">Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEE</p>
                        </div>
                        <div class="p-4 sec-1-rt">
                            <div class="sec-1-icon-box d-flex align-items-center justify-content-center mb-0 mb-md-4 bg-white"><img src="images/sec-1-1 (1).png"></div>
                            <h5 class="mb-0 mb-md-4 ml-4 ml-md-0">JEE MAINS</h5>
                            <p class="mb-0">Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEE</p>
                        </div>
                        <div class="p-4 sec-1-rt">
                            <div class="sec-1-icon-box d-flex align-items-center justify-content-center mb-0 mb-md-4 bg-white"><img src="images/sec-1-1 (3).png"></div>
                            <h5 class="mb-0 mb-md-4 ml-4 ml-md-0">ACADEMIC 4 - 10</h5>
                            <p class="mb-0">Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEE</p>
                        </div>
                        <div class="p-4 sec-1-rt">
                            <div class="sec-1-icon-box d-flex align-items-center justify-content-center mb-0 mb-md-4 bg-white"><img src="images/sec-1-1 (3).png"></div>
                            <h5 class="mb-0 mb-md-4 ml-4 ml-md-0">Fast Track</h5>
                            <p class="mb-0">Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEE</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <h2 class="heading mb-5 ">Welcome To <span class="under-dec">Vidiyarthi</span> <br>Educational Platorm</h2>
                    <div class="content mb-5">
                        <p>Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEEentrance examination. We are backed by rich experience of Vidiyarthi Group (A Pioneer Organisation in Education Field). </p>
                    </div>
                    <button class="rounded main-btn-bk border-0 py-2 px-4 text-white">Coming Soon</button>
                </div>
                <div class="col-12 col-md-4 offset-md-2 pr-md-5 mt-5 mt-md-0 abt-rt">

                    <div class="position-relative">
                        <div class="shape-box-1 rounded"></div>
                        <img src="images/Frame 20-4.png" style="width: 100%;z-index: 2;position: relative;height: 236px;margin-bottom: 15px;">
                        <img src="images/Frame 20-4.png" style="width: 100%;z-index: 2;position: relative;height: 274px;">
                    </div>
                    <div class="position-relative">
                        <div class="shape-box-2 rounded"></div>
                        <img src="images/Frame 20-4.png" style="width: 100%;z-index: 2;position: relative;height: 340px;margin-top: 60px;/* margin-left: 15px; */">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid main-bk py-5">
        <div class="container">
            <div class="row">
                <h2 class="heading mb-5 text-center">Syllabus of Your <span class="under-dec">Subjects</span></h2>
                <div class="col-12">
                    <div class="syllabus-subject">
                        <div class="lyqp-card  p-4 rounded position-relative sky">
                            <div class="q-icon-box d-flex align-items-center justify-content-center mb-4 bg-white"><i class="far fa-file"></i></div>
                            <h4>Questions Title</h4>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                            <div class="lyqp-overlay">
                                <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-download"></i></a>
                            </div>
                        </div>
                        <div class="lyqp-card  p-4 rounded position-relative green">
                            <div class="q-icon-box d-flex align-items-center justify-content-center mb-4 bg-white"><i class="far fa-file"></i></div>
                            <h4>Questions Title</h4>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                            <div class="lyqp-overlay">
                                <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-download"></i></a>
                            </div>
                        </div>
                        <div class="lyqp-card  p-4 rounded position-relative blue">
                            <div class="q-icon-box d-flex align-items-center justify-content-center mb-4 bg-white"><i class="far fa-file"></i></div>
                            <h4>Questions Title</h4>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                            <div class="lyqp-overlay">
                                <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-download"></i></a>
                            </div>
                        </div>
                        <div class="lyqp-card p-4 rounded position-relative red">
                            <div class="q-icon-box d-flex align-items-center justify-content-center mb-4 bg-white"><i class="far fa-file"></i></div>
                            <h4>Questions Title</h4>
                            <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                            <div class="lyqp-overlay">
                                <a class="mb-3" href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-download"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid main-bl-bk py-5">
        <div class="container">
            <div class="row">
                <div class="sec-2-wrap">
                    <div class="bg-white py-4 px-5 rounded text-center">
                        <b>NEET</b>
                    </div>
                    <div class="bg-white py-4 px-5 rounded text-center">
                        <b>NEET</b>
                    </div>
                    <div class="bg-white py-4 px-5 rounded text-center">
                        <b>NEET</b>
                    </div>
                    <div class="bg-white py-4 px-5 rounded text-center">
                        <b>NEET</b>
                    </div>
                    <div class="bg-white py-4 px-5 rounded text-center">
                        <b>NEET</b>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <h2 class="heading mb-5 text-center">Advantages of <span class="under-dec">Vidiyarthi</span></h2>
                <div class="col-12">
                    <ul class="adv">
                        <li>
                            <p><i class="fas fa-check"></i>Online Study Platform comprising of an extremely experienced Core faculties</p>
                        </li>
                        <li>
                            <p><i class="fas fa-check"></i>Attractive Scholarship for Toppers</p>
                        </li>
                        <li>
                            <p><i class="fas fa-check"></i>Meticulous individual performance analysis</p>
                        </li>
                        <li>
                            <p><i class="fas fa-check"></i>Extremely helpful comprehensive Video Lectures molded according to the current JEE and NEET pattern</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid pt-5 main-bk featr-wrap">
        <div class="container">
            <div class="row">
                <h2 class="heading mb-5 text-center">Advantages of <span class="under-dec">Vidiyarthi</span></h2>
                <div class="col-12 col-md-10 offset-md-1 featr">
                    <div>
                        <div class="feature-img-box  d-flex align-items-center justify-content-center">
                            <img src="images/ft-1.png">
                        </div>
                        <p class="mb-0 text-center">System-Based Organization</p>
                    </div>
                    <div>
                        <div class="feature-img-box d-flex align-items-center justify-content-center">
                            <img src="images/ft-1.png">
                        </div>
                        <p class="mb-0 text-center">System-Based Organization</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5 vdo-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8 offset-md-2 p-md-4 rounded bg-white">
                <iframe class="rounded y-ifram" width="100%" src="https://www.youtube.com/embed/h_IhUTfszpA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
    <? include_once("includes/last-year-ques-papper.php"); ?>
    <div class="containe-fluid py-5 main-bl-bk">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <h2 class="heading mb-5 text-white">Download <span class="under-dec">Mobile</span> App</h2>
                    <div class="content text-white mb-5">
                        <p>Vidiyarthi is a 3 step ahead preparation platform for aspiring students of JEE, NEET & other entrance examination. We are backed by rich experience of Vidiyarthi Group (A Pioneer Organisation in Education Field). </p>
                    </div>
                    <a class="andorid-btn mt-1 rounded" href="#"><img src="images/image 15.png">AVAILABLE ON PLAY STORE</a>
                </div>
                <div class="col-12 col-md-6 position-relative">
                    <img src="images/image 35.png" class="app-view">
                   
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5 magazine">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-10 offset-md-1">
                    <div class="row" style="align-items: center;">
                        <div class="col-12 col-md-5 pr-md-5 position-relative">
                            <img src="images/Frame 20-4.png" style="width: 100%;z-index: 2;position: relative;">
                            <img class="m-v-l" src="images/Vector 1.png" >
                            <img class="m-v-r" src="images/Vector 2.png" >
                            <img class="m-v-tl" src="images/Frame 190.png">
                        </div>
                        <div class="col-12 col-md-5 offset-md-2 pl-md-5 mt-5 mt-md-0">
                            <h2 class="heading mb-5">Career <span class="under-dec">Magazine</span></h2>
                            <button class="rounded main-btn-bk border-0 py-2 px-4 text-white">Coming Soon</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid main-bk py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 pr-4">
                    <h2 class="heading mb-5">Student <span class="under-dec">Speech</span></h2>
                    <div class="st-speech-wrap">
                        <div class="owl-carousel owl-theme studentspeech">
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t1.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t2.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t3.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                        </div>
                        <script>
                            $('.studentspeech').owlCarousel({
                                loop: false,
                                margin: 30,
                                nav: true,
                                dots: false,
                                autoplay: false,
                                responsive: {
                                    0: {
                                        items: 1
                                    },
                                    600: {
                                        items: 3
                                    },
                                    1000: {
                                        items: 2
                                    }
                                }
                            })
                        </script>
                    </div>

                </div>
                <div class="col-12 col-md-6 pl-4">
                    <h2 class="heading mb-5">Student <span class="under-dec">Speech</span></h2>
                    <div class="st-speech-wrap">
                        <div class="owl-carousel owl-theme studentspeech">
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t1.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t2.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="lyqp-card bg-white p-4 rounded position-relative">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="images/t3.png" class="testi-avatar">
                                        <h5 class="mb-0 ml-3">Name</h5>
                                    </div>
                                    <p class="mb-0">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                </div>
                            </div>
                        </div>
                        <script>
                            $('.studentspeech').owlCarousel({
                                loop: false,
                                margin: 30,
                                nav: true,
                                dots: false,
                                autoplay: false,
                                responsive: {
                                    0: {
                                        items: 1
                                    },
                                    600: {
                                        items: 3
                                    },
                                    1000: {
                                        items: 2
                                    }
                                }
                            })
                        </script>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2 class="heading mb-5 text-center">Our <span class="under-dec">Blog</span></h2>
                    <div class="st-speech-wrap">
                        <div class="owl-carousel owl-theme blog">
                            <div class="item">
                                <div class="blog-card bg-white  rounded position-relative">
                                    <div class="blog-image">
                                        <img src="images/Frame 20.png" class="h-100 rounded">
                                    </div>
                                    <div class="p-4">
                                        <h4>Blog Title</h4>
                                        <p class="mb-4">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <p class="border-left text-muted pl-3">By Admin</p>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="blog-card bg-white  rounded position-relative">
                                    <div class="blog-image">
                                        <img src="images/Frame 20-1.png" class="h-100 rounded">
                                    </div>
                                    <div class="p-4">
                                        <h4>Blog Title</h4>
                                        <p class="mb-4">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <p class="border-left text-muted pl-3">By Admin</p>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="blog-card bg-white  rounded position-relative">
                                    <div class="blog-image">
                                        <img src="images/Frame 20-2.png" class="h-100 rounded">
                                    </div>
                                    <div class="p-4">
                                        <h4>Blog Title</h4>
                                        <p class="mb-4">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <p class="border-left text-muted pl-3">By Admin</p>
                                    </div>

                                </div>
                            </div>
                            <div class="item">
                                <div class="blog-card bg-white  rounded position-relative">
                                    <div class="blog-image">
                                        <img src="images/Frame 20-3.png" class="h-100 rounded">
                                    </div>
                                    <div class="p-4">
                                        <h4>Blog Title</h4>
                                        <p class="mb-4">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic</p>
                                        <p class="border-left text-muted pl-3">By Admin</p>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <script>
                            $('.blog').owlCarousel({
                                loop: false,
                                margin: 30,
                                nav: true,
                                dots: false,
                                autoplay: false,
                                responsive: {
                                    0: {
                                        items: 1
                                    },
                                    600: {
                                        items: 3
                                    },
                                    1000: {
                                        items: 4
                                    }
                                }
                            })
                        </script>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>

</html>